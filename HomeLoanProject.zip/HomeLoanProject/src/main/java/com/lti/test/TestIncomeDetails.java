package com.lti.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.dao.HomeLoanDaoInterface;
import com.lti.entity.BankDetails;
import com.lti.entity.CustomerDetails;




public class TestIncomeDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext ctx=new ClassPathXmlApplicationContext("springpractice.xml");
		
HomeLoanDaoInterface ob=(HomeLoanDaoInterface)ctx.getBean("income");
//
//IncomeDetails id=new IncomeDetails();
//id.setEmployeeName("Sunil");
//id.setOrganizationType("Govt.");
//id.setRetirementAge(62);
//id.setTypeOfEmployment("Lecturer");
//ob.addNewRecord(id);
//

//CustomerDetails cd=new CustomerDetails();

CustomerDetails cusd=(CustomerDetails)ob.fetchById(CustomerDetails.class, 122);
//IncomeDetails id1=new IncomeDetails();
//id1.setEmployeeName("Vijay");
//id1.setOrganizationType("Private Ltd");
//id1.setRetirementAge(55);
//id1.setTypeOfEmployment("Clerk");
//id1.setCustdetails(cusd);
//ob.addNewRecord(id1);


//IncomeDetails id2=new IncomeDetails();
//String name1=cusd.getFname();
//String name2=cusd.getMname();
//String name3=cusd.getLname();

//id2.setEmployeeName(name1+" "+name2+" "+name3);
//id2.setOrganizationType("Music Studio");
//id2.setRetirementAge(50);
//id2.setTypeOfEmployment("Singer");
//id2.setCustdetails(cusd);
//ob.addNewRecord(id2);

//cd.setFname("Ashish");
//cd.setLname("Patil");
//cd.setGender("Male");
//cd.setDob(LocalDate.of(1998, 4, 17));
//cd.setEmail("ashish9817@gmail.com");
//cd.setAadharNo(458963257990L);
//cd.setNationality("Indian");
//cd.setPan("QWER2521FS");
//cd.setPhno(1254968378L);
//cd.setAddress("Ward No.-25, Shivajinagar,Kothrud,Pune(M.H.)");
//ob.addNewRecord(cd);
//CustomerDetails cusd=(CustomerDetails)ob.fetchById(CustomerDetails.class, 122);
//DocumentStatus docsta=new DocumentStatus();
//docsta.setStatus("Approved");
//docsta.setCustdetails(cusd);
//ob.addNewRecord(docsta);
//IncomeDetails list=(IncomeDetails)ob.fetchById(IncomeDetails.class, 160);
//System.out.println(list);
//PropertyDetails ppd=new PropertyDetails();
//ppd.setPropId(415263);
//ppd.setProplocation("Nagpur");
//ppd.setEstamount(19600000);
//ppd.setCustDetails(cusd);
//ob.addNewRecord(ppd);
//CustomerDetails cusd1=(CustomerDetails)ob.fetchById(CustomerDetails.class, 160);
BankDetails bd= new BankDetails();
bd.setAccountNo(7586954123l);
bd.setBranch("Standard Chatered");
bd.setIfsc("SC452369");
bd.setCreditscore(630);
bd.setCustdetails(cusd);
ob.addNewRecord(bd);

//BankDetails blist=(BankDetails)ob.fetchById(BankDetails.class, 7586954123L);
//System.out.println(blist);

//Appointmentdate aptdate=new Appointmentdate();
//aptdate.setApptDate();
//aptdate.setApptTime();
//aptdate.set

	}

}
