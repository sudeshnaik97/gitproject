$(document).ready(function(){
$("img").hide();
$("#id1").click(function(){
$("#img1").show();
});
});